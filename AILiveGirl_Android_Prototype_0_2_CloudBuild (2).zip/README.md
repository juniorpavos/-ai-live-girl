# AI LIVE GIRL — prototipo Android 0.2

Este proyecto es un prototipo inicial que muestra la cámara frontal usando CameraX.

## Estado real
- Implementado: vista previa de cámara frontal.
- No implementado: transformación facial en tiempo real.
- No implementado: conversión de voz femenina.
- No implementado: envío de cámara o audio directamente a TikTok LIVE.

## Compilación
El flujo de GitHub Actions incluido compila un APK de depuración al subir el proyecto a la rama `main` o al ejecutar manualmente el workflow.

La APK de depuración sirve para pruebas. No garantiza compatibilidad con TikTok LIVE ni monetización.
